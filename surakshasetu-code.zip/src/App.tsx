import React, { useState } from 'react';
import { TabType } from './types';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { EmergencyOpsView } from './components/EmergencyOpsView';
import { MissingFinderView } from './components/MissingFinderView';
import { CrowdFlowView } from './components/CrowdFlowView';
import { DeskSyncView } from './components/DeskSyncView';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('emergency-ops');

  return (
    <div className="min-h-screen bg-[#0f131d] text-[#dfe2f1] flex flex-col relative selection:bg-[#f59e0b] selection:text-[#472a00]">
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onSosClick={() => setCurrentTab('emergency-ops')}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full pt-22 pb-24 flex flex-col">
        {currentTab === 'emergency-ops' && <EmergencyOpsView />}
        {currentTab === 'missing-finder' && <MissingFinderView />}
        {currentTab === 'crowd-flow' && <CrowdFlowView />}
        {currentTab === 'desk-sync' && <DeskSyncView />}
      </main>

      {/* Bottom Tactical Navigation */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={(tab) => setCurrentTab(tab)}
      />
    </div>
  );
}
