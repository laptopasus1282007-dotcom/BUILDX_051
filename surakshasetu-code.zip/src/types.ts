export type TabType = 'emergency-ops' | 'missing-finder' | 'crowd-flow' | 'desk-sync';

export interface SightingLead {
  id: string;
  location: string;
  status: 'DESK VERIFIED' | 'FIELD CHECKING' | 'RESOLVED';
  note: string;
  time: string;
  verifier: string;
  image?: string;
  hasRadar?: boolean;
}

export interface IncidentItem {
  id: string;
  type: 'CRITICAL' | 'MEDICAL' | 'PROPERTY';
  categoryTitle: string;
  title: string;
  description: string;
  timeAgo: string;
  liveDesksCount?: number;
  image?: string;
  sightingPing?: string;
  actionPrimary?: string;
  actionSecondary?: string;
  eta?: string;
  statusBadge: string;
  resolved?: boolean;
}

export interface SectorCapacity {
  id: string;
  name: string;
  subtext: string;
  percentage: number;
  ratePerMin: string;
  statusBadge: string;
  statusType: 'critical' | 'bottleneck' | 'moderate' | 'optimal';
  color: string;
  recommendation?: string;
  note?: string;
}

export interface TipReport {
  category: string;
  details: string;
  hasPhoto: boolean;
  timestamp: string;
}
