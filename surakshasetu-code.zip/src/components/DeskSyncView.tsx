import React, { useState } from 'react';
import { IncidentItem } from '../types';

export const DeskSyncView: React.FC = () => {
  const [filter, setFilter] = useState<'ALL' | 'CRITICAL' | 'MEDICAL' | 'RESOLVED'>('ALL');
  const [intakeModalOpen, setIntakeModalOpen] = useState<boolean>(false);
  const [flashModalOpen, setFlashModalOpen] = useState<boolean>(false);
  const [flashSuccess, setFlashSuccess] = useState<boolean>(false);
  const [flashSubject, setFlashSubject] = useState<string>('');
  const [isTalking, setIsTalking] = useState<boolean>(false);
  const [isDictating, setIsDictating] = useState<boolean>(false);
  const [ticketToast, setTicketToast] = useState<{ id: string; msg: string } | null>(null);

  // New ticket state
  const [ticketCategory, setTicketCategory] = useState<'Missing' | 'Medical' | 'Belonging'>('Missing');
  const [ticketDesc, setTicketDesc] = useState<string>('');
  const [ticketPhone, setTicketPhone] = useState<string>('');
  const [ticketLocation, setTicketLocation] = useState<string>('');

  const [incidents, setIncidents] = useState<IncidentItem[]>([
    {
      id: '8429',
      type: 'CRITICAL',
      categoryTitle: '#8429 • CRITICAL',
      title: 'Missing: Ananya (6y)',
      description: 'Yellow kurti, red sandals, speaking Marathi/Hindi. Separated near Stupa gate.',
      timeAgo: '17:42 (6m ago)',
      liveDesksCount: 18,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB1gLTLDwkFrbPubWDuyLvlivBasYyJ1cfcksWOte5gNxM6GO0tFIAhC8cuasnitBrimJtF8mIItNVXiguWMK2_U3-kpdgA5HJpZxRBJRbw3QJVpSjQcbMWtuDChszs_5SLqz8m1cuaBeyciGjNZjNFnxcOg79eIqBPdJiKhIGplX5yUCFPYmK7Hv11v_m2-WiH3sB9I-8T9Ea9iNOahSNuZ0eC9ZTTlzIvL1kmhFUwj2TgJwQr1Vvd-Q',
      sightingPing: 'Sighting ping: Gate 2 food stall (Officer Rao on scene)',
      actionPrimary: 'Update Rao',
      actionSecondary: 'PA Broadcast (300m)',
      statusBadge: 'LIVE ON 18 DESKS'
    },
    {
      id: '8428',
      type: 'MEDICAL',
      categoryTitle: '#8428 • MEDICAL',
      title: 'Elderly Dehydration / Collapse',
      description: 'Zone C shaded pavilion, male ~68y. Responders deployed with IV fluids.',
      timeAgo: '17:36 (12m ago)',
      eta: 'ETA: 90 seconds (Sector 3 bypass)',
      statusBadge: 'DISPATCHED'
    },
    {
      id: '8425',
      type: 'PROPERTY',
      categoryTitle: '#8425 • PROPERTY',
      title: 'Brown Leather Wallet & Chandrapur Bus Pass',
      description: 'Citizen Ramesh G. identified biometric matching pass. Safely returned.',
      timeAgo: '17:15 (33m ago)',
      statusBadge: 'RESOLVED',
      resolved: true
    }
  ]);

  const filteredIncidents = incidents.filter((item) => {
    if (filter === 'ALL') return true;
    if (filter === 'CRITICAL') return item.type === 'CRITICAL';
    if (filter === 'MEDICAL') return item.type === 'MEDICAL';
    if (filter === 'RESOLVED') return item.resolved;
    return true;
  });

  const handleCreateIntake = (e: React.FormEvent) => {
    e.preventDefault();
    setIntakeModalOpen(false);

    const newId = (8430 + Math.floor(Math.random() * 50)).toString();
    const newItem: IncidentItem = {
      id: newId,
      type: ticketCategory === 'Missing' ? 'CRITICAL' : ticketCategory === 'Medical' ? 'MEDICAL' : 'PROPERTY',
      categoryTitle: `#${newId} • ${ticketCategory.toUpperCase()}`,
      title: ticketDesc || `Walk-in report: ${ticketCategory}`,
      description: `Reported by citizen (${ticketPhone || 'Walk-in'}). Location: ${ticketLocation || 'Sector 4'}.`,
      timeAgo: 'Just now',
      liveDesksCount: 18,
      statusBadge: 'LIVE ON 18 DESKS'
    };

    setIncidents([newItem, ...incidents]);
    setTicketToast({
      id: newId,
      msg: 'Broadcasted to 18 Help Desks & 34 Sector Volunteers in 0.8s'
    });
    setTicketDesc('');
    setTicketPhone('');
    setTicketLocation('');

    setTimeout(() => {
      setTicketToast(null);
    }, 4000);
  };

  const handleFlashBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    setFlashModalOpen(false);
    setFlashSuccess(true);
    setTicketToast({
      id: 'FLASH-ALERT',
      msg: 'Priority siren and text flashed across all 18 desk terminals and patrol radios.'
    });
    setFlashSubject('');
    setTimeout(() => {
      setFlashSuccess(false);
      setTicketToast(null);
    }, 4000);
  };

  return (
    <div className="flex flex-col w-full px-4 space-y-3.5 max-w-md mx-auto sm:max-w-xl md:max-w-2xl pb-6">
      {/* Operational Header & Sync Bar */}
      <div className="bg-[#262a35] rounded-xl p-3.5 shadow-md border border-[#313540]">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></div>
            <span className="font-chivo font-bold text-base text-[#dfe2f1]">Help Desk #04</span>
            <span className="font-mono-code text-[10px] px-1.5 py-0.5 rounded bg-[#313540] text-[#ffc174] font-bold">
              SECTOR EAST
            </span>
          </div>
          <div className="flex items-center gap-1 bg-[#0a0e18] px-2 py-1 rounded border border-[#1c1f2a]">
            <span className="material-symbols-outlined text-xs text-[#4cd7f6]">sensors</span>
            <span className="font-mono-code text-[10px] text-[#4cd7f6]">MESH + 5G ACTIVE</span>
          </div>
        </div>

        <div className="flex items-center justify-between text-[#d8c3ad] text-xs pt-1">
          <div className="flex items-center gap-1.5 truncate">
            <span className="material-symbols-outlined text-base text-[#f59e0b]">badge</span>
            <span className="truncate">
              On Duty: <strong className="text-[#dfe2f1] font-medium">Officer Priya Sharma (IPS Aux)</strong>
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-emerald-400 font-semibold whitespace-nowrap">
            0.4s LATENCY
          </span>
        </div>

        {/* Paper Registry Replacement Metric Callout */}
        <div className="mt-2.5 bg-[#171b26] rounded-lg p-2.5 flex items-center justify-between border border-[#1c1f2a]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#f59e0b]/20 flex items-center justify-center text-[#f59e0b]">
              <span className="material-symbols-outlined text-lg">bolt</span>
            </div>
            <div>
              <div className="font-mono-code text-[9px] text-[#d8c3ad] uppercase">
                Inter-Desk Delay Eradicated
              </div>
              <div className="font-mono-code text-[11px] text-[#ffc174] font-bold">
                25m Manual Lag → 1.2s Real-Time Sync
              </div>
            </div>
          </div>
          <span className="font-mono-code text-[10px] text-[#54ddfc] px-2 py-0.5 rounded bg-[#313540]">
            18 Desks Live
          </span>
        </div>
      </div>

      {/* Primary Rapid Walk-In Action Row */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => setIntakeModalOpen(true)}
          className="h-14 bg-[#ffc174] text-[#472a00] rounded-xl flex items-center justify-center gap-2 px-3 active:scale-95 transition-transform shadow-md cursor-pointer hover:bg-[#ffb95f]"
        >
          <span className="material-symbols-outlined text-2xl">add_circle</span>
          <div className="flex flex-col text-left">
            <span className="font-chivo font-bold text-sm leading-none text-[#472a00]">
              + New Intake
            </span>
            <span className="font-mono-code text-[10px] text-[#653e00] mt-0.5">
              Citizen Walk-in Log
            </span>
          </div>
        </button>

        <button
          onClick={() => setFlashModalOpen(true)}
          className="h-14 bg-[#a40217] text-[#ffdad6] rounded-xl flex items-center justify-center gap-2 px-3 active:scale-95 transition-transform shadow-lg shadow-[#a40217]/30 cursor-pointer hover:bg-[#93000a]"
        >
          <span className="material-symbols-outlined text-2xl animate-pulse">campaign</span>
          <div className="flex flex-col text-left">
            <span className="font-chivo font-bold text-sm leading-none uppercase">
              Flash Alert
            </span>
            <span className="font-mono-code text-[10px] opacity-90 mt-0.5">
              18 Desks + 34 Patrols
            </span>
          </div>
        </button>
      </div>

      {/* Real-Time Walkie-Talkie (PTT) Strip */}
      <div className="bg-[#171b26] rounded-xl p-3 border border-[#262a35]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#f59e0b] text-lg">cell_tower</span>
            <span className="font-mono-code text-[11px] text-[#dfe2f1] font-bold uppercase tracking-wider">
              Tactical Mesh Intercom (PTT)
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-[#d8c3ad] bg-[#1c1f2a] px-1.5 py-0.5 rounded">
            Channel 04 • All-Desk
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsTalking(!isTalking)}
            className={`min-h-[46px] px-3.5 rounded-xl flex items-center gap-2 transition-all flex-shrink-0 cursor-pointer ${
              isTalking
                ? 'bg-[#93000a] text-white shadow-[0_0_12px_rgba(239,68,68,0.6)]'
                : 'bg-[#313540] hover:bg-[#353944] text-[#dfe2f1]'
            }`}
          >
            <span className="material-symbols-outlined text-xl text-[#f59e0b]">
              {isTalking ? 'record_voice_over' : 'mic'}
            </span>
            <span className="font-mono-code text-[11px] font-bold uppercase">
              {isTalking ? 'Transmitting...' : 'Push to Talk'}
            </span>
          </button>

          {/* Live audio transcription stream */}
          <div className="flex-grow min-w-0 bg-[#0a0e18] rounded-lg p-2 flex items-center gap-2 border border-[#1c1f2a]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0 animate-pulse"></span>
            <div className="truncate text-xs text-[#d8c3ad]">
              <span className="font-mono-code text-[10px] text-[#54ddfc] mr-1">[Desk #02]</span>
              <span className="italic text-[#dfe2f1]">
                "Officer Rao confirmed sighting ping at Gate 2."
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Synchronized Incident Queue Header & Filter Tabs */}
      <div className="flex flex-col space-y-2 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#f59e0b] text-xl">sync_saved_locally</span>
            <span className="font-chivo font-bold text-base text-[#dfe2f1]">Live Incident Registry</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="font-mono-code text-[10px] text-[#d8c3ad]">Queue:</span>
            <span className="font-mono-code text-[11px] bg-[#f59e0b] text-[#613b00] font-bold px-1.5 py-0.5 rounded">
              {incidents.filter((i) => !i.resolved).length} Active
            </span>
          </div>
        </div>

        {/* Rapid triage filter pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {(['ALL', 'CRITICAL', 'MEDICAL', 'RESOLVED'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-full font-mono-code text-[10px] font-bold flex-shrink-0 cursor-pointer transition-colors ${
                filter === tab
                  ? 'bg-[#f59e0b] text-[#613b00]'
                  : 'bg-[#262a35] text-[#dfe2f1] hover:bg-[#313540]'
              }`}
            >
              {tab === 'ALL'
                ? `ALL INCIDENTS (${incidents.length})`
                : tab === 'CRITICAL'
                ? `CRITICAL KHOJ (${incidents.filter((i) => i.type === 'CRITICAL').length})`
                : tab === 'MEDICAL'
                ? `MEDICAL (${incidents.filter((i) => i.type === 'MEDICAL').length})`
                : `RESOLVED (${incidents.filter((i) => i.resolved).length})`}
            </button>
          ))}
        </div>
      </div>

      {/* Incident List */}
      <div className="space-y-3">
        {filteredIncidents.map((item) => (
          <div
            key={item.id}
            className={`rounded-xl p-3.5 shadow-md border ${
              item.type === 'CRITICAL'
                ? 'bg-[#171b26] border-[#a40217]/50 shadow-[#a40217]/10'
                : item.resolved
                ? 'bg-[#171b26]/70 border-[#262a35] opacity-85'
                : 'bg-[#171b26] border-[#262a35]'
            }`}
          >
            <div className="flex items-start justify-between gap-2 pb-1.5">
              <div className="flex items-center gap-2">
                <span
                  className={`px-2 py-0.5 rounded font-mono-code text-[10px] font-bold tracking-wider ${
                    item.type === 'CRITICAL'
                      ? 'bg-[#93000a] text-[#ffdad6]'
                      : item.type === 'MEDICAL'
                      ? 'bg-[#f59e0b]/20 text-[#ffc174]'
                      : 'bg-[#313540] text-[#d8c3ad]'
                  }`}
                >
                  {item.categoryTitle}
                </span>
                <span
                  className={`font-mono-code text-[10px] font-bold ${
                    item.type === 'CRITICAL'
                      ? 'text-[#ffb4ab] animate-pulse'
                      : item.type === 'MEDICAL'
                      ? 'text-[#54ddfc]'
                      : 'text-emerald-400'
                  }`}
                >
                  {item.statusBadge}
                </span>
              </div>
              <span className="font-mono-code text-[10px] text-[#d8c3ad]">{item.timeAgo}</span>
            </div>

            <div className="flex gap-3 mt-1">
              {item.image ? (
                <div className="w-18 h-18 rounded-lg overflow-hidden flex-shrink-0 bg-[#313540] ring-1 ring-[#f59e0b]/30">
                  <img
                    className="w-full h-full object-cover"
                    alt={item.title}
                    src={item.image}
                  />
                </div>
              ) : (
                <div className="w-11 h-11 rounded-lg bg-[#313540] flex items-center justify-center flex-shrink-0 text-[#ffc174]">
                  <span className="material-symbols-outlined text-2xl">
                    {item.type === 'MEDICAL' ? 'medical_services' : 'inventory_2'}
                  </span>
                </div>
              )}

              <div className="flex flex-col min-w-0 flex-grow justify-between">
                <div>
                  <h4 className="font-chivo font-bold text-sm text-[#dfe2f1] truncate">
                    {item.title}
                  </h4>
                  <p className="text-xs text-[#d8c3ad] line-clamp-2 mt-0.5 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {item.sightingPing && (
                  <div className="flex items-center gap-1 text-[#acedff] font-mono-code text-[10px] bg-[#1c1f2a] p-1 rounded mt-1.5 truncate border border-[#262a35]">
                    <span className="material-symbols-outlined text-xs flex-shrink-0">radar</span>
                    <span className="truncate">{item.sightingPing}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Sub-actions */}
            {item.type === 'CRITICAL' && (
              <div className="flex items-center justify-between gap-2 mt-3 pt-2 border-t border-[#262a35]">
                <button
                  onClick={() => alert('Broadcasting Marathi & Hindi announcement to 300m radius PA nodes.')}
                  className="h-10 flex-1 bg-[#313540] hover:bg-[#353944] text-[#dfe2f1] rounded-lg font-mono-code text-[10px] font-bold flex items-center justify-center gap-1.5 active:scale-98 transition-transform cursor-pointer"
                >
                  <span className="material-symbols-outlined text-base text-[#f59e0b]">
                    broadcast_on_home
                  </span>
                  PA Broadcast (300m)
                </button>
                <button
                  onClick={() => alert('Pinging Officer Rao at Gate 2 food stall via mesh.')}
                  className="h-10 flex-1 bg-[#ffc174] text-[#472a00] rounded-lg font-mono-code text-[10px] font-bold flex items-center justify-center gap-1.5 active:scale-98 transition-transform cursor-pointer hover:bg-[#ffb95f]"
                >
                  <span className="material-symbols-outlined text-base">connect_without_contact</span>
                  Update Rao
                </button>
              </div>
            )}

            {item.eta && (
              <div className="mt-2.5 bg-[#1c1f2a] rounded-lg p-2 flex items-center justify-between border border-[#262a35]">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-emerald-400 text-lg animate-pulse">
                    local_shipping
                  </span>
                  <div className="flex flex-col">
                    <span className="font-mono-code text-[10px] text-[#dfe2f1] font-semibold">
                      First Aid Mobile Van #02
                    </span>
                    <span className="text-xs text-[#d8c3ad]">{item.eta}</span>
                  </div>
                </div>
                <a
                  href="tel:108"
                  className="h-8 px-2.5 bg-[#313540] text-[#dfe2f1] rounded font-mono-code text-[10px] font-bold flex items-center gap-1 active:scale-95 cursor-pointer hover:bg-[#353944]"
                >
                  <span className="material-symbols-outlined text-xs">call</span>
                  Driver
                </a>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Tactical Volunteer Deployment Telemetry */}
      <div className="bg-[#262a35] rounded-xl p-3.5 shadow-sm border border-[#313540]">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#acedff] text-xl">groups</span>
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
              Volunteer Ground Grid
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-[#acedff] px-2 py-0.5 rounded bg-[#313540] font-bold">
            SECTOR 04
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-[#171b26] rounded-lg p-2.5 flex items-center gap-3 border border-[#1c1f2a]">
            <div className="w-10 h-10 rounded-lg bg-[#313540] flex items-center justify-center text-[#ffc174] font-bold font-chivo text-lg">
              34
            </div>
            <div className="flex flex-col">
              <span className="font-mono-code text-[10px] text-[#dfe2f1] font-bold uppercase">
                Active Scouts
              </span>
              <span className="text-xs text-[#d8c3ad]">Checked-in &amp; Syncing</span>
            </div>
          </div>

          <div className="bg-[#171b26] rounded-lg p-2.5 flex items-center gap-3 border border-[#1c1f2a]">
            <div className="w-10 h-10 rounded-lg bg-[#313540] flex items-center justify-center text-[#54ddfc] font-bold font-chivo text-lg">
              08
            </div>
            <div className="flex flex-col">
              <span className="font-mono-code text-[10px] text-[#dfe2f1] font-bold uppercase">
                Roving Patrols
              </span>
              <span className="text-xs text-[#d8c3ad]">Perimeter &amp; Shrines</span>
            </div>
          </div>
        </div>

        {/* Active Patrol Micro Roster */}
        <div className="mt-2.5 flex items-center justify-between text-[#d8c3ad] font-mono-code text-[10px] pt-1 bg-[#0a0e18]/50 px-2.5 py-1.5 rounded-lg border border-[#1c1f2a]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Patrol 4B: East Stupa Ramp (Lead: Tanmay)</span>
          </div>
          <span className="text-[#54ddfc]">Signal: 98%</span>
        </div>
      </div>

      {/* Sector 4 Inter-Desk Geofence */}
      <div className="bg-[#171b26] rounded-xl p-3 shadow-sm border border-[#262a35]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#f59e0b] text-lg">map</span>
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
              Sector 4 Inter-Desk Geofence
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-[#d8c3ad]">Radius 500m</span>
        </div>

        <div
          className="w-full h-36 bg-cover bg-center rounded-lg relative overflow-hidden border border-[#313540]"
          style={{
            backgroundImage:
              "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAvN5df7tTpowCCZSC85ifIASqOLgPDOC8rOWTiFrJ8fjnijtLumroXIJ__CYz-AvoxJ_NXZERAdWv2LRlxc5HU2VHs0Lou4wOZ2VzCYnUGWSG4AoFZKALFpne7fOg8LRCXzOOW2DSpw7loW0OO5u8KJ7KW1NRWsPBBdIlXziNkKBrLOLrE4b1Ns2W8-ZgC0Ya6Jvw52BShGNj6yBSsak8Me72bBwlD5_8Dig2m50fJKuk4qBCvFWsJfA')"
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e18]/90 via-transparent to-transparent flex flex-col justify-end p-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 bg-[#262a35]/90 px-2 py-1 rounded backdrop-blur-sm border border-[#313540]">
                <span className="w-2 h-2 rounded-full bg-[#f59e0b] animate-ping"></span>
                <span className="font-mono-code text-[10px] text-[#dfe2f1] font-bold">
                  Help Desk #04 (You)
                </span>
              </div>
              <span className="font-mono-code text-[10px] text-[#acedff] bg-[#262a35]/90 px-2 py-1 rounded backdrop-blur-sm border border-[#313540]">
                4 Adjacent Desks in Mesh Range
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Citizen Walk-in Quick Intake Modal */}
      {intakeModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0a0e18]/80 backdrop-blur-md flex flex-col justify-end p-0 sm:p-4 sm:items-center sm:justify-center">
          <div className="bg-[#262a35] rounded-t-2xl sm:rounded-2xl p-4 w-full max-w-lg max-h-[85vh] overflow-y-auto space-y-3 shadow-2xl border border-[#313540]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#f59e0b] text-2xl">
                  edit_document
                </span>
                <div>
                  <h3 className="font-chivo font-bold text-base text-[#dfe2f1]">
                    Citizen Walk-in Intake
                  </h3>
                  <span className="font-mono-code text-[9px] text-[#54ddfc] font-bold">
                    AUTO-TAGGED TO DESK #04 • REAL-TIME MESH BROADCAST
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIntakeModalOpen(false)}
                className="w-8 h-8 rounded-full bg-[#313540] text-[#dfe2f1] flex items-center justify-center active:scale-90 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {/* Voice-to-Text Bar */}
            <div className="bg-[#0a0e18] rounded-xl p-2.5 flex items-center justify-between border border-[#1c1f2a]">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsDictating(!isDictating)}
                  className={`min-h-[40px] min-w-[40px] rounded-lg flex items-center justify-center active:scale-95 transition-transform cursor-pointer ${
                    isDictating
                      ? 'bg-[#93000a] text-white animate-pulse'
                      : 'bg-[#f59e0b] text-[#613b00]'
                  }`}
                >
                  <span className="material-symbols-outlined text-lg">mic</span>
                </button>
                <div className="flex flex-col">
                  <span className="font-mono-code text-[11px] text-[#dfe2f1] font-bold">
                    {isDictating ? 'Listening...' : 'Voice-to-Text Intake'}
                  </span>
                  <span className="text-[11px] text-[#d8c3ad]">
                    Tap mic and speak Marathi, Hindi, or English
                  </span>
                </div>
              </div>
              <div className="flex gap-1">
                <span className="px-2 py-1 rounded bg-[#1c1f2a] text-[#ffc174] font-mono-code text-[10px] font-bold">
                  मराठी
                </span>
                <span className="px-2 py-1 rounded bg-[#1c1f2a] text-[#d8c3ad] font-mono-code text-[10px]">
                  हिंदी
                </span>
              </div>
            </div>

            {/* Intake Form Fields */}
            <div className="space-y-2.5">
              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">
                  INCIDENT CATEGORY
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Missing', 'Medical', 'Belonging'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setTicketCategory(cat)}
                      className={`h-10 rounded-lg font-mono-code text-[10px] font-bold flex items-center justify-center gap-1 active:scale-95 cursor-pointer ${
                        ticketCategory === cat
                          ? 'bg-[#ffc174] text-[#472a00]'
                          : 'bg-[#313540] text-[#dfe2f1] hover:bg-[#353944]'
                      }`}
                    >
                      <span className="material-symbols-outlined text-sm">
                        {cat === 'Missing'
                          ? 'person_search'
                          : cat === 'Medical'
                          ? 'medical_services'
                          : 'backpack'}
                      </span>
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">
                  PERSON / ITEM DESCRIPTION
                </label>
                <input
                  type="text"
                  value={ticketDesc}
                  onChange={(e) => setTicketDesc(e.target.value)}
                  placeholder="e.g. Ramesh Kumar, 72y, blue Nehru jacket..."
                  className="w-full h-11 bg-[#0a0e18] rounded-lg px-3 text-[#dfe2f1] text-xs focus:outline-none focus:ring-1 focus:ring-[#f59e0b] border border-[#1c1f2a]"
                />
              </div>

              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">
                  REPORTING CITIZEN CONTACT &amp; LOCATION DETAILED
                </label>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    value={ticketPhone}
                    onChange={(e) => setTicketPhone(e.target.value)}
                    placeholder="+91 Mobile number"
                    className="w-1/2 h-11 bg-[#0a0e18] rounded-lg px-3 text-[#dfe2f1] text-xs focus:outline-none focus:ring-1 focus:ring-[#f59e0b] border border-[#1c1f2a]"
                  />
                  <input
                    type="text"
                    value={ticketLocation}
                    onChange={(e) => setTicketLocation(e.target.value)}
                    placeholder="Last seen near..."
                    className="w-1/2 h-11 bg-[#0a0e18] rounded-lg px-3 text-[#dfe2f1] text-xs focus:outline-none focus:ring-1 focus:ring-[#f59e0b] border border-[#1c1f2a]"
                  />
                </div>
              </div>

              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">
                  PHOTO ATTACHMENT (CAMERA / GALLERY)
                </label>
                <div className="w-full h-16 rounded-lg bg-[#0a0e18] flex items-center justify-center gap-2 text-[#d8c3ad] active:bg-[#313540] transition-colors cursor-pointer border border-dashed border-[#313540]">
                  <span className="material-symbols-outlined text-xl text-[#f59e0b]">
                    add_a_photo
                  </span>
                  <span className="font-mono-code text-[10px] text-[#dfe2f1]">
                    Capture or Upload Reference Photo
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-1">
              <button
                type="button"
                onClick={handleCreateIntake}
                className="w-full h-12 py-3 bg-[#ffc174] text-[#472a00] rounded-xl font-chivo font-bold text-sm flex items-center justify-center gap-2 active:scale-98 transition-transform shadow-lg cursor-pointer hover:bg-[#ffb95f]"
              >
                <span className="material-symbols-outlined text-xl">cloud_sync</span>
                Sync &amp; Dispatch to All 18 Desks
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Flash Alert Broadcast Modal */}
      {flashModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0a0e18]/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-[#1c1f2a] rounded-t-2xl sm:rounded-2xl p-4 w-full max-w-lg space-y-3 shadow-2xl border border-[#a40217]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#ffb4ab] text-2xl animate-pulse">
                  emergency_share
                </span>
                <div>
                  <h3 className="font-chivo font-bold text-base text-[#dfe2f1]">
                    Mass Flash Broadcast
                  </h3>
                  <span className="font-mono-code text-[9px] text-[#ffb4ab]">
                    EMERGENCY OVERRIDE FOR ALL 18 DESK MONITORS &amp; PATROLS
                  </span>
                </div>
              </div>
              <button
                onClick={() => setFlashModalOpen(false)}
                className="w-8 h-8 rounded-full bg-[#262a35] text-[#dfe2f1] flex items-center justify-center active:scale-90 cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-2">
              <label className="font-mono-code text-[10px] text-[#d8c3ad] block">
                BROADCAST MESSAGE (AUTOMATICALLY REPEATED IN MARATHI &amp; HINDI)
              </label>
              <textarea
                rows={3}
                value={flashSubject}
                onChange={(e) => setFlashSubject(e.target.value)}
                placeholder="e.g. Urgent cordon required at North-East gate due to incoming procession surge..."
                className="w-full bg-[#0a0e18] text-[#dfe2f1] p-2.5 rounded-lg text-xs border border-[#262a35] focus:outline-none focus:border-[#ffb4ab]"
              ></textarea>
            </div>

            <div className="p-2.5 rounded bg-[#93000a]/20 text-[#ffb4ab] text-xs flex items-center gap-2 border border-[#93000a]/40">
              <span className="material-symbols-outlined text-lg">warning</span>
              <span>This will ring an audible emergency klaxon on all active volunteer terminals.</span>
            </div>

            <button
              onClick={handleFlashBroadcast}
              className="w-full h-12 bg-[#a40217] text-[#ffdad6] rounded-xl font-chivo font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined">campaign</span>
              Transmit Red Flash Broadcast
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Toast */}
      {ticketToast && (
        <div className="fixed top-24 left-4 right-4 max-w-md mx-auto bg-emerald-950 text-emerald-200 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-50 border border-emerald-700/50">
          <span className="material-symbols-outlined text-2xl text-emerald-400">task_alt</span>
          <div className="flex flex-col min-w-0">
            <span className="font-chivo font-bold text-sm text-white">
              Ticket #{ticketToast.id} Active
            </span>
            <span className="text-xs text-emerald-300">{ticketToast.msg}</span>
          </div>
        </div>
      )}
    </div>
  );
};
