import React from 'react';
import { TabType } from '../types';

interface HeaderProps {
  currentTab: TabType;
  onSosClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, onSosClick }) => {
  const getSubTitle = () => {
    switch (currentTab) {
      case 'emergency-ops':
        return 'Emergency Ops';
      case 'missing-finder':
        return 'Missing Finder';
      case 'crowd-flow':
        return 'Crowd Flow';
      case 'desk-sync':
        return 'Desk Sync';
    }
  };

  return (
    <header className="fixed top-0 w-full z-50 pt-safe bg-[#0f131d]/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.3)]">
      <div className="h-20 px-4 flex items-center justify-between gap-2 max-w-md mx-auto sm:max-w-xl md:max-w-2xl">
        <div className="flex items-center gap-2.5 min-w-0">
          <img
            alt="SurakshaSetu Brand Logo"
            className="h-8 w-auto object-contain flex-shrink-0"
            src="https://lh3.googleusercontent.com/aida/AEtjO1VbsdOsmwLhVHU2MMGSAV48bxokNQDah6CZqjtw0jgkg5rEXBxhNAZevnALTW6uxLjVzo7Fqhiv0g0yeBIL5HHKykcoosGaP1P1PIACODw1Rnw6CFFrH5MD9p5Gy2gLkp3P743km_004fhuDsCcbCHw_n_BojlqqvOvw6bFAmWSu4G2fbwND-e2gWDJtBhVZAsrBrduD8gvsxsNtVSvKkGJyVi5wmE-3loBVp1di1RoGw"
          />
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-chivo font-bold text-lg text-[#dfe2f1] tracking-tight truncate">
                SurakshaSetu
              </span>
              <div className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#262a35]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="font-mono-code text-[10px] text-[#d8c3ad] whitespace-nowrap">
                  Deekshabhoomi Live Ops
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <span className="font-mono-code text-[10px] text-[#ffc174] uppercase font-bold tracking-wider truncate">
                {getSubTitle()}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={onSosClick}
            className="min-h-[44px] min-w-[44px] h-11 px-3 rounded bg-[#a40217] text-[#ffdad6] flex items-center justify-center gap-1 active:scale-95 transition-transform shadow-[0_0_12px_rgba(164,2,23,0.5)] cursor-pointer"
            title="Emergency SOS Quick Trigger"
          >
            <span className="material-symbols-outlined text-xl">emergency</span>
            <span className="font-mono-code text-xs uppercase font-bold hidden sm:inline">SOS</span>
          </button>
          
          <div className="relative flex items-center justify-center min-h-[44px] min-w-[44px]">
            <img
              alt="Profile"
              className="w-8 h-8 rounded-full object-cover ring-2 ring-[#f59e0b]/40"
              src="https://lh3.googleusercontent.com/aida/AEtjO1WRb3aqfj12A5xeeS8u_wT8Hs2wpy-EjpAgd1939kpGD6jKquCHyLYtx6ehfHbAy2jwcRJN73Qh1W2NAkcRnFdW-695Lea_g9hxfGChggjzIfUuYSZumcbpW-65sjMVdCgbm1mZLHHj69Uq8xaFRnfrXwLeOaoyy5xbPpYamzD_npP9ruY45OtXNLNSRJnPcncU025AAeJwxnSnhtfYo8poIDmOHOeHrc_-GCeZoPFZtA"
            />
            <span className="absolute bottom-1 right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#0f131d]"></span>
          </div>
        </div>
      </div>
    </header>
  );
};
