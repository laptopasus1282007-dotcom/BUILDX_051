import React from 'react';
import { TabType } from '../types';

interface BottomNavProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onSelectTab }) => {
  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: 'emergency-ops', label: 'Emergency', icon: 'sos' },
    { id: 'missing-finder', label: 'Khoj/Alerts', icon: 'person_search' },
    { id: 'crowd-flow', label: 'Sectors', icon: 'hub' },
    { id: 'desk-sync', label: 'Field Ops', icon: 'sync_saved_locally' },
  ];

  return (
    <nav className="fixed bottom-0 w-full z-50 pb-safe bg-[#171b26]/95 backdrop-blur-xl shadow-[0_-2px_12px_rgba(0,0,0,0.4)] border-t border-[#1c1f2a]">
      <div className="flex justify-around items-center h-16 px-3 max-w-md mx-auto sm:max-w-xl md:max-w-2xl">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 transition-all cursor-pointer select-none active:scale-95 ${
                isActive
                  ? 'text-[#f59e0b]'
                  : 'text-[#d8c3ad]/70 hover:text-[#dfe2f1]'
              }`}
            >
              <span className={`material-symbols-outlined text-2xl ${isActive ? 'scale-110' : ''}`}>
                {tab.icon}
              </span>
              <span className={`font-mono-code text-[11px] tracking-tight mt-0.5 ${isActive ? 'font-bold text-[#ffc174]' : 'font-medium'}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b] mt-0.5"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
