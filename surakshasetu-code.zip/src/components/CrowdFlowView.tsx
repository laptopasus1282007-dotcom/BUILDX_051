import React, { useState } from 'react';
import { SectorCapacity } from '../types';

export const CrowdFlowView: React.FC = () => {
  const [selectedGate, setSelectedGate] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string; icon: string } | null>(null);
  const [auxiliaryExitOpened, setAuxiliaryExitOpened] = useState<boolean>(false);

  const [sectors, setSectors] = useState<SectorCapacity[]>([
    {
      id: 'gate-2',
      name: 'Exit Gate 2',
      subtext: 'Wardha Road Concourse',
      percentage: 94,
      ratePerMin: '+420/min',
      statusBadge: '94% CRITICAL',
      statusType: 'critical',
      color: '#ffb4ab',
      recommendation: 'Recommends: Open Auxiliary Exit B'
    },
    {
      id: 'gate-3',
      name: 'Exit Gate 3',
      subtext: 'Subhash Nagar Approach',
      percentage: 86,
      ratePerMin: '+310/min',
      statusBadge: '86% BOTTLENECK',
      statusType: 'bottleneck',
      color: '#f59e0b',
      note: 'Pacing marshals on-site: 14 officers'
    },
    {
      id: 'stupa',
      name: 'Central Stupa Parikrama',
      subtext: 'Core Monolithic Dome Area',
      percentage: 62,
      ratePerMin: '+180/min',
      statusBadge: '62% MODERATE',
      statusType: 'moderate',
      color: '#54ddfc',
      note: 'Movement rhythm steady • Rotation 8m avg'
    },
    {
      id: 'gate-1',
      name: 'Gate 1 Ceremonial',
      subtext: 'Laxmi Nagar Main Transit',
      percentage: 48,
      ratePerMin: 'Discharge Open',
      statusBadge: '48% OPTIMAL',
      statusType: 'optimal',
      color: '#10b981'
    }
  ]);

  const showToast = (title: string, desc: string, icon: string) => {
    setToastMessage({ title, desc, icon });
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handlePagingAudio = () => {
    showToast(
      'PA Dispatch Triggered',
      'Automated Marathi/Hindi advisory sent to Sector 4 speakers.',
      'campaign'
    );
  };

  const handleReportChokepoint = () => {
    showToast(
      'Incident Tagged: Gate 2 Outer',
      'Field marshals dispatched with crowd control ribbon kits.',
      'add_alert'
    );
  };

  const handleExecuteAuxExit = () => {
    setAuxiliaryExitOpened(true);
    setSectors((prev) =>
      prev.map((sec) =>
        sec.id === 'gate-2'
          ? {
              ...sec,
              percentage: 78,
              statusBadge: '78% RELIEVED',
              recommendation: 'Auxiliary Exit B Opened • Load Decreasing'
            }
          : sec
      )
    );
    showToast(
      'Auxiliary Gate B Deployed',
      'Turnstiles unlocked, volunteer barrier redirection in progress.',
      'check_circle'
    );
  };

  return (
    <div className="flex flex-col w-full px-4 space-y-4 max-w-md mx-auto sm:max-w-xl md:max-w-2xl pb-6">
      {/* Sector Grid 04 Live Inflow Telemetry */}
      <div className="bg-[#262a35] rounded-xl p-3.5 shadow-md flex flex-col gap-1 relative overflow-hidden border border-[#313540]">
        <div className="absolute -right-4 -bottom-4 w-28 h-28 bg-[#f59e0b]/10 rounded-full blur-xl pointer-events-none"></div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b] animate-ping"></span>
            <span className="font-mono-code text-[10px] uppercase tracking-wider text-[#ffc174] font-semibold">
              Sector Grid 04 • Live Inflow Telemetry
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-[#d8c3ad] bg-[#313540] px-2 py-0.5 rounded">
            Synced 4s ago
          </span>
        </div>

        <div className="flex flex-col mt-0.5">
          <span className="font-chivo font-bold text-base text-[#dfe2f1]">
            Deekshabhoomi Complex
          </span>
          <div className="flex items-baseline gap-1.5 mt-0.5">
            <span className="font-chivo font-extrabold text-2xl text-[#f59e0b]">
              4.2 Lakh
            </span>
            <span className="text-xs text-[#d8c3ad]">Estimated Present Peak</span>
          </div>
        </div>

        <div className="mt-1 inline-flex items-center gap-1.5 bg-[#a40217]/30 px-2 py-1 rounded w-fit border border-[#a40217]/40">
          <span className="material-symbols-outlined text-[#ffb3ad] text-base">warning</span>
          <span className="font-mono-code text-[10px] uppercase text-[#ffb3ad] font-bold tracking-wide">
            Status: Elevated Caution
          </span>
        </div>
      </div>

      {/* Citizen Reroute Advisory Banner */}
      <div className="bg-gradient-to-r from-[#a40217] via-[#262a35] to-[#1c1f2a] p-3.5 rounded-xl shadow-lg flex flex-col gap-1.5 border border-[#a40217]/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#ffb4ab] text-xl animate-pulse">alt_route</span>
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">Citizen Reroute Advisory</span>
          </div>
          <span className="font-mono-code text-[10px] bg-[#93000a] text-[#ffdad6] px-2 py-0.5 rounded font-bold uppercase">
            Critical Divert
          </span>
        </div>

        <p className="text-xs text-[#dfe2f1] leading-relaxed">
          <strong className="text-[#ffb4ab]">Avoid Exit 2.</strong> Density reached 94%. Divert incoming movement via{' '}
          <span className="text-[#ffc174] font-bold">North Corridor</span> to{' '}
          <span className="text-emerald-400 font-bold">Gate 4</span>.
        </p>

        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1 text-[#d8c3ad]">
            <span className="material-symbols-outlined text-sm">timer</span>
            <span className="font-mono-code text-[10px]">
              Est. evacuation transit: <strong className="text-[#dfe2f1]">4 mins</strong>
            </span>
          </div>
          <button
            onClick={handlePagingAudio}
            className="min-h-[40px] px-3.5 bg-[#f59e0b] text-[#613b00] rounded font-mono-code text-[11px] uppercase font-bold active:scale-95 transition-transform flex items-center gap-1 shadow-sm cursor-pointer"
          >
            <span className="material-symbols-outlined text-base">campaign</span>
            Paging Audio
          </button>
        </div>
      </div>

      {/* Active Chokepoint Map */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <span className="font-chivo font-bold text-sm text-[#dfe2f1] tracking-tight">
            Active Chokepoint Map
          </span>
          <span className="font-mono-code text-[10px] text-[#ffc174] flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b] animate-pulse"></span>
            4 Core Sectors
          </span>
        </div>

        <div
          className="w-full h-44 bg-[#1c1f2a] rounded-xl overflow-hidden relative shadow-md bg-cover bg-center border border-[#313540]"
          style={{
            backgroundImage:
              "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAvN5df7tTpowCCZSC85ifIASqOLgPDOC8rOWTiFrJ8fjnijtLumroXIJ__CYz-AvoxJ_NXZERAdWv2LRlxc5HU2VHs0Lou4wOZ2VzCYnUGWSG4AoFZKALFpne7fOg8LRCXzOOW2DSpw7loW0OO5u8KJ7KW1NRWsPBBdIlXziNkKBrLOLrE4b1Ns2W8-ZgC0Ya6Jvw52BShGNj6yBSsak8Me72bBwlD5_8Dig2m50fJKuk4qBCvFWsJfA')"
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e18] via-[#0a0e18]/40 to-transparent"></div>

          {/* Thermal Layer Badge */}
          <div className="absolute top-2.5 left-2.5 bg-[#0a0e18]/90 px-2 py-1 rounded backdrop-blur-md flex items-center gap-1.5 shadow-sm border border-[#313540]">
            <span className="material-symbols-outlined text-[#54ddfc] text-xs">radar</span>
            <span className="font-mono-code text-[10px] text-[#dfe2f1]">Thermal Density Layer</span>
          </div>

          {/* Marker 2: Gate 2 */}
          <button
            onClick={() => {
              setSelectedGate('Gate 2');
              showToast('Isolating Gate 2 Stream', 'Direct camera telemetry active (94% load)', 'videocam');
            }}
            className="absolute top-1/4 left-1/3 flex flex-col items-center cursor-pointer active:scale-95 transition-transform"
          >
            <span className="relative flex h-5 w-5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#93000a] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-5 w-5 bg-[#93000a] items-center justify-center text-[10px] text-white font-bold border border-white/40">
                2
              </span>
            </span>
            <span className="bg-[#0a0e18]/90 text-[#ffb4ab] font-mono-code text-[9px] px-1.5 py-0.5 rounded mt-0.5 shadow-sm border border-[#93000a]/50">
              Gate 2 (94%)
            </span>
          </button>

          {/* Marker 3: Gate 3 */}
          <button
            onClick={() => {
              setSelectedGate('Gate 3');
              showToast('Isolating Gate 3 Stream', 'Flow stabilizing with 14 officers on-site', 'traffic');
            }}
            className="absolute bottom-6 right-1/4 flex flex-col items-center cursor-pointer active:scale-95 transition-transform"
          >
            <span className="relative flex h-5 w-5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#f59e0b] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-5 w-5 bg-[#f59e0b] items-center justify-center text-[10px] text-[#472a00] font-bold">
                3
              </span>
            </span>
            <span className="bg-[#0a0e18]/90 text-[#ffc174] font-mono-code text-[9px] px-1.5 py-0.5 rounded mt-0.5 shadow-sm border border-[#f59e0b]/50">
              Gate 3 (86%)
            </span>
          </button>

          {/* Marker 1: Gate 1 */}
          <button
            onClick={() => {
              setSelectedGate('Gate 1');
              showToast('Gate 1 Ceremonial', 'Discharge clear and optimal (48%)', 'check_circle');
            }}
            className="absolute top-7 right-10 flex flex-col items-center cursor-pointer active:scale-95 transition-transform"
          >
            <span className="h-3.5 w-3.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] border border-white/60"></span>
            <span className="bg-[#0a0e18]/90 text-emerald-400 font-mono-code text-[9px] px-1.5 py-0.5 rounded mt-0.5 shadow-sm">
              Gate 1
            </span>
          </button>

          <div className="absolute bottom-2.5 left-2.5 bg-[#0a0e18]/80 px-2 py-0.5 rounded text-[#d8c3ad] font-mono-code text-[9px]">
            Tap marker to isolate flow feed
          </div>
        </div>
      </div>

      {/* Sector Capacity Breakdown */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
            Sector Capacity Breakdown
          </span>
          <span className="font-mono-code text-[10px] text-[#d8c3ad]">Live Sensors</span>
        </div>

        {sectors.map((sec) => (
          <div
            key={sec.id}
            className="bg-[#1c1f2a] p-3 rounded-xl shadow-md flex flex-col gap-2 border border-[#262a35]"
          >
            <div className="flex items-start justify-between">
              <div className="flex flex-col min-w-0 pr-2">
                <div className="flex items-center gap-1.5">
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: sec.color }}
                  ></span>
                  <span className="font-chivo font-bold text-sm text-[#dfe2f1] truncate">
                    {sec.name}
                  </span>
                </div>
                <span className="text-xs text-[#d8c3ad]">{sec.subtext}</span>
              </div>
              <div className="flex flex-col items-end flex-shrink-0">
                <span
                  className={`font-mono-code text-[10px] uppercase px-2 py-0.5 rounded font-bold ${
                    sec.statusType === 'critical'
                      ? 'bg-[#93000a] text-[#ffdad6]'
                      : sec.statusType === 'bottleneck'
                      ? 'bg-[#f59e0b]/20 text-[#ffc174]'
                      : sec.statusType === 'moderate'
                      ? 'bg-[#29c1df]/20 text-[#54ddfc]'
                      : 'bg-emerald-950/60 text-emerald-400'
                  }`}
                >
                  {sec.statusBadge}
                </span>
                <span className="font-mono-code text-[10px] text-[#d8c3ad] mt-0.5">
                  {sec.ratePerMin}
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-[#0a0e18] h-2 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${sec.percentage}%`,
                  backgroundColor:
                    sec.statusType === 'critical'
                      ? '#ffb4ab'
                      : sec.statusType === 'bottleneck'
                      ? '#f59e0b'
                      : sec.statusType === 'moderate'
                      ? '#54ddfc'
                      : '#10b981'
                }}
              ></div>
            </div>

            {sec.recommendation && (
              <div className="bg-[#0a0e18] p-2 rounded flex items-center justify-between border border-[#262a35]">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="material-symbols-outlined text-[#f59e0b] text-base">
                    assistant_direction
                  </span>
                  <span className="text-xs text-[#ffc174] truncate">
                    {sec.recommendation}
                  </span>
                </div>
                {!auxiliaryExitOpened && (
                  <button
                    onClick={handleExecuteAuxExit}
                    className="min-h-[36px] px-3 bg-[#262a35] hover:bg-[#353944] text-[#dfe2f1] rounded font-mono-code text-[10px] uppercase flex items-center justify-center active:scale-95 transition-transform cursor-pointer ml-2"
                  >
                    Execute
                  </button>
                )}
              </div>
            )}

            {sec.note && (
              <div className="flex items-center justify-between text-[#d8c3ad] pt-0.5 text-xs">
                <span>{sec.note}</span>
                <span className="font-mono-code text-[10px] text-[#54ddfc]">
                  Flow Stabilizing
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* AI CCTV & Sensor Telemetry */}
      <div className="bg-[#262a35] p-3.5 rounded-xl shadow-md flex flex-col gap-2.5 border border-[#313540]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#54ddfc] text-lg">videocam</span>
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
              AI CCTV &amp; Sensor Telemetry
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-[#ffc174] uppercase font-bold">
            12 Turnstiles Active
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-[#0a0e18] p-2.5 rounded flex flex-col gap-1 border border-[#1c1f2a]">
            <span className="font-mono-code text-[10px] text-[#d8c3ad]">Aggregated Inflow</span>
            <span className="font-chivo font-bold text-base text-[#f59e0b]">
              1,840 <span className="font-mono-code text-[10px] font-normal text-[#d8c3ad]">p/min</span>
            </span>
            <div className="h-6 w-full flex items-end gap-1 mt-1">
              <div className="w-full bg-[#f59e0b]/40 h-[40%] rounded-t-xs"></div>
              <div className="w-full bg-[#f59e0b]/60 h-[60%] rounded-t-xs"></div>
              <div className="w-full bg-[#f59e0b]/50 h-[50%] rounded-t-xs"></div>
              <div className="w-full bg-[#f59e0b]/80 h-[80%] rounded-t-xs"></div>
              <div className="w-full bg-[#f59e0b] h-[95%] rounded-t-xs"></div>
            </div>
          </div>

          <div className="bg-[#0a0e18] p-2.5 rounded flex flex-col gap-1 border border-[#1c1f2a]">
            <span className="font-mono-code text-[10px] text-[#d8c3ad]">Gate Discharge Rate</span>
            <span className="font-chivo font-bold text-base text-[#54ddfc]">
              1,210 <span className="font-mono-code text-[10px] font-normal text-[#d8c3ad]">p/min</span>
            </span>
            <div className="h-6 w-full flex items-end gap-1 mt-1">
              <div className="w-full bg-[#54ddfc]/50 h-[65%] rounded-t-xs"></div>
              <div className="w-full bg-[#54ddfc]/60 h-[70%] rounded-t-xs"></div>
              <div className="w-full bg-[#54ddfc]/40 h-[45%] rounded-t-xs"></div>
              <div className="w-full bg-[#54ddfc]/50 h-[55%] rounded-t-xs"></div>
              <div className="w-full bg-[#54ddfc] h-[60%] rounded-t-xs"></div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 pt-1">
          <div className="w-12 h-12 rounded bg-[#0a0e18] flex items-center justify-center flex-shrink-0 overflow-hidden ring-1 ring-[#313540]">
            <img
              className="w-full h-full object-cover"
              alt="Cam 09 Corridor"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBJHFdr-JM5oa9jelfxvk7-vgfqxcxKjpn3AGQGxo_2ay3iwaZ4ZuZU85hCP_AnQkbNrITUuuC_PTr-Q0K-j062kqMb1hrymG_GAvkbV2ozbhNffonBYYxlh6YYteVqzNc-UspwtrWXOuoZGgf6iNydV1W8A4cAwZbOIDSLGwnL1QDI9zjtR8i81N4EZXpQ0XFxK7SDspZxMVWguodh4_-20qEzrT3gZMf9k8fXW5gvWaHw8LXK9ePwuQ"
            />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-mono-code text-[11px] text-[#dfe2f1] font-semibold truncate">
              Cam #09 - Gate 2 Corridor
            </span>
            <span className="text-xs text-[#d8c3ad]">AI Headcount accuracy: 98.4%</span>
          </div>
          <span className="font-mono-code text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded ml-auto flex-shrink-0">
            LIVE
          </span>
        </div>
      </div>

      {/* Report Bottleneck CTA */}
      <div className="flex flex-col gap-1 pt-1">
        <button
          onClick={handleReportChokepoint}
          className="w-full min-h-[50px] bg-[#a40217] text-[#ffdad6] rounded-xl font-chivo font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-lg cursor-pointer"
        >
          <span className="material-symbols-outlined text-2xl">pin_drop</span>
          <span>Report Chokepoint / Medical Halt</span>
        </button>
        <div className="flex items-center justify-center gap-1 text-[#d8c3ad] text-center pt-0.5">
          <span className="material-symbols-outlined text-xs">my_location</span>
          <span className="font-mono-code text-[10px]">
            Automatically attaches your current GPS coordinate pin
          </span>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-4 right-4 max-w-md mx-auto bg-[#313540]/95 backdrop-blur-md p-3.5 rounded-xl shadow-2xl flex items-center gap-3 z-50 border border-[#534434]">
          <span className="material-symbols-outlined text-[#f59e0b] text-2xl">
            {toastMessage.icon}
          </span>
          <div className="flex flex-col min-w-0">
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
              {toastMessage.title}
            </span>
            <span className="text-xs text-[#d8c3ad]">{toastMessage.desc}</span>
          </div>
        </div>
      )}
    </div>
  );
};
