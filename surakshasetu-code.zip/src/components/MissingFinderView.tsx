import React, { useState } from 'react';
import { SightingLead } from '../types';

export const MissingFinderView: React.FC = () => {
  const [sightingModalOpen, setSightingModalOpen] = useState<boolean>(false);
  const [sightingReported, setSightingReported] = useState<boolean>(false);
  const [reportDossierOpen, setReportDossierOpen] = useState<boolean>(false);
  const [dossierCategory, setDossierCategory] = useState<string>('child');
  const [missingName, setMissingName] = useState<string>('');
  const [missingAge, setMissingAge] = useState<string>('');
  const [missingDesc, setMissingDesc] = useState<string>('');
  const [recentReunions, setRecentReunions] = useState([
    { name: 'Rameshwar K. (71 yrs)', location: 'Reunited at North Gate 2', time: '14m ago' },
    { name: 'Aarav Borkar (4 yrs)', location: 'Reunited at Sector 3 Helpdesk', time: '38m ago' }
  ]);

  const [leads, setLeads] = useState<SightingLead[]>([
    {
      id: 'lead-1',
      location: 'Gate #3 Food Queue',
      status: 'DESK VERIFIED',
      note: 'Volunteer spotted child with matching pink footwear.',
      time: '5:58 PM',
      verifier: 'Verified by Vol. Akash S.',
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCDWHqhQYUv2VSXXDi76doyE8bPPudqjAQp784fYkqWtbIqhVEbYn4N5EJ1e_AGlir5xYikV6TqtJGOM8pGUZtPKsiqu12tE0YGrnL6Lj57wdmGu0ZewsZHX1Gdwtf9Uc-HBDymY_A_6m9DvLHoL-9QrStE55g3KvbjigJeLR5YD5wfXClru8qlaniTD3_qWVhTJ6wi83eyGmqvTYokfsFcU5FwLcUcqlgMYDUwHlQPgKMNitelQigeSA'
    },
    {
      id: 'lead-2',
      location: 'Ashoka Garden Kiosk',
      status: 'FIELD CHECKING',
      note: 'Citizen uploaded snapshot of unattended toddler.',
      time: '5:54 PM',
      verifier: 'Team #08 En Route',
      hasRadar: true
    }
  ]);

  const handleSightingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSightingModalOpen(false);
    setSightingReported(true);

    // Prepend new verified lead
    const newLead: SightingLead = {
      id: `lead-${Date.now()}`,
      location: 'Sector 3 • North Parikrama',
      status: 'FIELD CHECKING',
      note: 'Live match candidate photographed by citizen applet.',
      time: 'Just now',
      verifier: 'Desk #4 Notified & En Route',
      hasRadar: true
    };
    setLeads([newLead, ...leads]);

    setTimeout(() => {
      setSightingReported(false);
    }, 4000);
  };

  const handleCreateDossier = (e: React.FormEvent) => {
    e.preventDefault();
    setReportDossierOpen(false);
    setSightingReported(true);
    setTimeout(() => {
      setSightingReported(false);
    }, 4000);
  };

  return (
    <div className="flex flex-col w-full px-4 space-y-3.5 max-w-md mx-auto sm:max-w-xl md:max-w-2xl pb-6">
      {/* Network Synchronized Telemetry Bar */}
      <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#262a35] text-[#dfe2f1] shadow-sm border border-[#313540]">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#f59e0b] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#f59e0b]"></span>
          </span>
          <span className="font-mono-code text-[11px] text-[#ffc174] tracking-wider uppercase font-semibold">
            Mesh Khoj-Net
          </span>
        </div>
        <div className="flex items-center gap-3 text-[#d8c3ad] font-mono-code text-[10px]">
          <span className="flex items-center gap-1">
            <span className="material-symbols-outlined text-sm text-[#f59e0b]">sensors</span>
            18/18 Desks Live
          </span>
          <span className="w-1 h-3 bg-[#313540] rounded-full"></span>
          <span className="flex items-center gap-1">
            <span className="material-symbols-outlined text-sm text-[#54ddfc]">groups</span>
            350 Volunteers
          </span>
        </div>
      </div>

      {/* Priority Alert Card: Ananya Meshram */}
      <div className="relative overflow-hidden rounded-xl bg-[#1c1f2a] p-3.5 shadow-xl border border-[#a40217]/50">
        <div className="absolute inset-0 bg-gradient-to-r from-[#a40217]/20 via-[#f59e0b]/10 to-transparent pointer-events-none"></div>

        {/* Alert Header Pill */}
        <div className="flex items-center justify-between gap-1 mb-2.5 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#a40217] text-[#ffdad6]">
            <span className="material-symbols-outlined text-base animate-pulse">campaign</span>
            <span className="font-mono-code text-[11px] tracking-wider uppercase font-bold">
              #KHOJ-8429 • Urgent Broadcast
            </span>
          </div>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#313540] text-[#54ddfc] font-mono-code text-[10px]">
            <span className="material-symbols-outlined text-xs">verified_user</span>
            <span>Desk #4 Verified</span>
          </div>
        </div>

        {/* Person Details Profile */}
        <div className="flex gap-3 items-start relative z-10">
          <div className="relative flex-shrink-0">
            <img
              className="w-24 h-24 rounded-lg object-cover bg-[#0a0e18] ring-1 ring-[#f59e0b]/40"
              alt="Ananya Meshram"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBtyCgiCsIm5yj8qw6Nzz8S0i7aI1Y333p7qiT4eFrtcBH0RnVOVpgbYvMuZFcQJRN9XndkZ6JjKvEDcIYV5fK2mxZaw_0a9LnT3WLQnbnm0Ra7dcmfjEZSKuGhP31GQKmcg5T8Gb_MTRWSFDlzp2GNqBuZ_Lac3-RwwvRpC2rm2MJFS0KT6UllNNvKD77gaoFPHD8QNAki0sWaZp3daI9EoaPWEDuNtmmJBCaGulgk63JsbD_QP6rzBw"
            />
            <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#a40217] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-[#a40217] items-center justify-center text-[9px] text-white font-bold">
                !
              </span>
            </span>
          </div>

          <div className="flex flex-col min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-1">
              <h2 className="font-chivo font-bold text-base text-[#dfe2f1] truncate">
                Ananya Meshram
              </h2>
              <span className="font-mono-code text-xs text-[#ffc174] font-bold">Age 6</span>
            </div>
            <p className="text-xs text-[#d8c3ad] mt-0.5">
              Origin: Chandrapur • Marathi / Hindi speaker
            </p>

            {/* Vital Metas */}
            <div className="mt-1.5 flex flex-wrap gap-1">
              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-[#262a35] text-[#dfe2f1] font-mono-code text-[10px]">
                <span className="material-symbols-outlined text-xs mr-1 text-[#f59e0b]">schedule</span>
                5:40 PM (22m ago)
              </span>
              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-[#262a35] text-[#dfe2f1] font-mono-code text-[10px]">
                <span className="material-symbols-outlined text-xs mr-1 text-[#54ddfc]">near_me</span>
                Central Stupa Base
              </span>
            </div>
          </div>
        </div>

        {/* Descriptive Signals */}
        <div className="mt-2.5 p-2 rounded-lg bg-[#0a0e18] text-[#d8c3ad] text-xs relative z-10 space-y-1 border border-[#262a35]">
          <div className="flex items-center gap-1.5 text-[#dfe2f1] font-medium">
            <span className="material-symbols-outlined text-sm text-[#f59e0b]">checkroom</span>
            <span className="truncate">Yellow pleated dress, pink rubber sandals, black bead wrist thread</span>
          </div>
          <div className="flex items-center justify-between font-mono-code text-[10px] text-[#a08e7a] pt-1">
            <span>Parents: At Police Booth #4 (Sub-Insp. K. Patil)</span>
            <span className="text-[#54ddfc] font-semibold tracking-wide">ID: MH-34-R782</span>
          </div>
        </div>

        {/* PA Loudspeaker Broadcast Announcement Banner */}
        <div className="mt-2 flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-[#262a35] relative z-10">
          <div className="flex items-center gap-2 min-w-0">
            <span className="material-symbols-outlined text-[#54ddfc] text-base animate-pulse">volume_up</span>
            <span className="font-mono-code text-[10px] text-[#dfe2f1] truncate">
              Zones A, B, C &amp; Exits 1-4 PA System Engaged
            </span>
          </div>
          <span className="font-mono-code text-[10px] text-[#ffc174] px-1.5 py-0.5 rounded bg-[#171b26] font-bold uppercase">
            Marathi + Hi
          </span>
        </div>

        {/* High-Impact Direct Sighting Action */}
        <div className="mt-3 grid grid-cols-1 gap-1 relative z-10">
          <button
            onClick={() => setSightingModalOpen(true)}
            className="min-h-[48px] h-12 w-full px-4 rounded-xl bg-[#f59e0b] text-[#613b00] flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-md font-chivo text-sm font-bold tracking-wide cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">photo_camera</span>
            <span>I See This Child / Report Sighting</span>
          </button>
          <div className="flex items-center justify-between px-1 pt-1">
            <span className="font-mono-code text-[10px] text-[#a08e7a]">
              Direct priority dispatch to Ground Team 4
            </span>
            <a
              href="tel:0712250004"
              className="font-mono-code text-[10px] text-[#54ddfc] underline uppercase tracking-wider font-semibold cursor-pointer"
            >
              Call Desk #4
            </a>
          </div>
        </div>
      </div>

      {/* Sighting Verification Feed */}
      <div className="flex flex-col space-y-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#f59e0b] text-base">fact_check</span>
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
              Verified Sighting Feed
            </span>
          </div>
          <span className="font-mono-code text-[10px] px-2 py-0.5 rounded bg-[#262a35] text-[#ffb95f]">
            {leads.length} Live Leads
          </span>
        </div>

        <div className="space-y-1.5">
          {leads.map((lead) => (
            <div
              key={lead.id}
              className="flex items-center justify-between p-2.5 rounded-xl bg-[#171b26] text-[#dfe2f1] border border-[#262a35]"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="relative flex-shrink-0">
                  {lead.image ? (
                    <img
                      className="w-12 h-12 rounded object-cover bg-[#0a0e18]"
                      alt={lead.location}
                      src={lead.image}
                    />
                  ) : (
                    <div className="w-12 h-12 rounded bg-[#262a35] flex items-center justify-center text-[#f59e0b]">
                      <span className="material-symbols-outlined text-2xl">radar</span>
                    </div>
                  )}
                  {lead.image && (
                    <span className="absolute bottom-0 right-0 p-0.5 rounded-full bg-[#313540]">
                      <span className="material-symbols-outlined text-xs text-[#54ddfc]">pin_drop</span>
                    </span>
                  )}
                </div>

                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono-code text-[11px] text-[#dfe2f1] font-semibold truncate">
                      {lead.location}
                    </span>
                    <span
                      className={`font-mono-code text-[9px] px-1.5 py-0.2 rounded font-bold ${
                        lead.status === 'DESK VERIFIED'
                          ? 'bg-[#29c1df] text-[#003640]'
                          : 'bg-[#313540] text-[#ffb95f]'
                      }`}
                    >
                      {lead.status}
                    </span>
                  </div>
                  <p className="text-xs text-[#d8c3ad] truncate mt-0.5">{lead.note}</p>
                  <span className="font-mono-code text-[10px] text-[#a08e7a] mt-0.5">
                    {lead.time} • {lead.verifier}
                  </span>
                </div>
              </div>

              <button
                onClick={() => alert(`Locating team for ${lead.location}`)}
                className="h-9 min-h-[36px] min-w-[36px] px-2 rounded bg-[#262a35] text-[#f59e0b] flex items-center justify-center flex-shrink-0 active:scale-95 cursor-pointer ml-2 hover:bg-[#313540]"
                title="Route to lead"
              >
                <span className="material-symbols-outlined text-lg">
                  {lead.image ? 'route' : 'visibility'}
                </span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Register New Missing / Sighting Action Card */}
      <div className="p-3.5 rounded-xl bg-[#1c1f2a] text-[#dfe2f1] space-y-2.5 shadow-md border border-[#262a35]">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="font-chivo font-bold text-sm text-[#dfe2f1]">
              Report Lost Person
            </span>
            <span className="text-xs text-[#d8c3ad]">
              Elderly, lost child, or disconnected pilgrim
            </span>
          </div>
          <div className="h-9 w-9 rounded-full bg-[#262a35] flex items-center justify-center text-[#ffc174]">
            <span className="material-symbols-outlined text-xl">person_add</span>
          </div>
        </div>

        {/* Registration Feature Triggers */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setReportDossierOpen(true)}
            className="min-h-[44px] p-2 rounded-lg bg-[#262a35] text-[#dfe2f1] flex items-center gap-2 text-left active:scale-95 transition-transform cursor-pointer hover:bg-[#313540]"
          >
            <span className="material-symbols-outlined text-[#54ddfc] text-xl">qr_code_scanner</span>
            <div className="flex flex-col min-w-0">
              <span className="font-mono-code text-[11px] font-bold truncate">Wristband NFC/QR</span>
              <span className="font-mono-code text-[9px] text-[#a08e7a] truncate">Scan Pilgrim Band</span>
            </div>
          </button>

          <button
            onClick={() => setReportDossierOpen(true)}
            className="min-h-[44px] p-2 rounded-lg bg-[#262a35] text-[#dfe2f1] flex items-center gap-2 text-left active:scale-95 transition-transform cursor-pointer hover:bg-[#313540]"
          >
            <span className="material-symbols-outlined text-[#f59e0b] text-xl">add_a_photo</span>
            <div className="flex flex-col min-w-0">
              <span className="font-mono-code text-[11px] font-bold truncate">Facial Ingest</span>
              <span className="font-mono-code text-[9px] text-[#a08e7a] truncate">Match CCTV Arch</span>
            </div>
          </button>
        </div>

        {/* Master Action CTA */}
        <button
          onClick={() => setReportDossierOpen(true)}
          className="min-h-[44px] h-11 w-full rounded-lg bg-[#353944] text-[#dfe2f1] flex items-center justify-center gap-2 font-chivo font-bold text-sm active:scale-98 transition-transform cursor-pointer hover:bg-[#313540]"
        >
          <span className="material-symbols-outlined text-[#ffc174] text-lg">post_add</span>
          <span>Create Rapid Field Dossier</span>
        </button>
      </div>

      {/* Reassurance & Rapid Ticker (Recent Reunions) */}
      <div className="p-2.5 rounded-xl bg-[#171b26] text-[#d8c3ad] space-y-1.5 border border-[#262a35]">
        <div className="flex items-center justify-between font-mono-code text-[10px] px-1">
          <span className="uppercase tracking-wider font-semibold text-[#a08e7a] flex items-center gap-1">
            <span className="material-symbols-outlined text-xs text-[#4cd7f6]">check_circle</span>
            Recently Reunited (Today: 42)
          </span>
          <span className="text-[#54ddfc] font-bold">Avg. 16m resolution</span>
        </div>

        {recentReunions.map((item, idx) => (
          <div
            key={idx}
            className="flex items-center gap-2 p-1.5 rounded bg-[#1c1f2a] text-[#dfe2f1]"
          >
            <div className="h-7 w-7 rounded-full bg-[#262a35] flex items-center justify-center text-[#ffb95f] flex-shrink-0">
              <span className="material-symbols-outlined text-base">sentiment_very_satisfied</span>
            </div>
            <div className="flex-1 min-w-0 text-xs truncate">
              <span className="font-semibold text-[#dfe2f1]">{item.name}</span>
              <span className="text-[#a08e7a]"> • {item.location}</span>
            </div>
            <span className="font-mono-code text-[9px] text-[#54ddfc] px-1.5 py-0.5 rounded bg-[#0a0e18] font-medium flex-shrink-0">
              {item.time}
            </span>
          </div>
        ))}
      </div>

      {/* Interactive Modal for Reporting Sighting */}
      {sightingModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0a0e18]/80 backdrop-blur-sm p-4 flex items-end sm:items-center justify-center">
          <div className="w-full max-w-md rounded-xl bg-[#1c1f2a] p-4 text-[#dfe2f1] space-y-3 shadow-2xl border border-[#313540]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#f59e0b]">add_location_alt</span>
                <span className="font-chivo font-bold text-base">Log Ananya Sighting</span>
              </div>
              <button
                onClick={() => setSightingModalOpen(false)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center text-[#d8c3ad] cursor-pointer"
              >
                <span className="material-symbols-outlined text-2xl">close</span>
              </button>
            </div>

            <div className="space-y-1">
              <label className="font-mono-code text-[11px] text-[#d8c3ad] uppercase">
                Current Checkpoint / Sector
              </label>
              <div className="p-2.5 rounded-lg bg-[#0a0e18] text-[#dfe2f1] flex items-center justify-between border border-[#262a35]">
                <span className="text-xs">Sector 3 • North Parikrama</span>
                <span className="font-mono-code text-[10px] text-[#ffc174]">GPS ±4m</span>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-[#0a0e18] flex flex-col items-center justify-center space-y-1.5 text-center border border-dashed border-[#313540]">
              <span className="material-symbols-outlined text-3xl text-[#54ddfc]">camera</span>
              <span className="text-xs text-[#dfe2f1] font-medium">Tap to snap instant match photo</span>
              <span className="font-mono-code text-[9px] text-[#a08e7a]">
                Instant vector comparison with #KHOJ-8429
              </span>
            </div>

            <button
              onClick={handleSightingSubmit}
              className="min-h-[48px] h-12 w-full rounded-lg bg-[#f59e0b] text-[#613b00] font-chivo font-bold text-sm uppercase tracking-wide cursor-pointer active:scale-95 transition-transform"
            >
              Broadcast to Desk #4 Team
            </button>
          </div>
        </div>
      )}

      {/* Interactive Modal for Creating New Dossier */}
      {reportDossierOpen && (
        <div className="fixed inset-0 z-50 bg-[#0a0e18]/85 backdrop-blur-md p-4 flex items-end sm:items-center justify-center">
          <div className="w-full max-w-md rounded-2xl bg-[#1c1f2a] p-4 text-[#dfe2f1] space-y-3 shadow-2xl border border-[#313540] max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#ffc174] text-xl">post_add</span>
                <span className="font-chivo font-bold text-base">New Lost Person Dossier</span>
              </div>
              <button
                onClick={() => setReportDossierOpen(false)}
                className="w-8 h-8 rounded-full bg-[#262a35] flex items-center justify-center text-[#d8c3ad] cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="space-y-2">
              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">TYPE</label>
                <div className="grid grid-cols-2 gap-2 font-mono-code text-[11px]">
                  <button
                    type="button"
                    onClick={() => setDossierCategory('child')}
                    className={`p-2 rounded cursor-pointer ${dossierCategory === 'child' ? 'bg-[#f59e0b] text-[#613b00] font-bold' : 'bg-[#262a35] text-[#dfe2f1]'}`}
                  >
                    Lost Child
                  </button>
                  <button
                    type="button"
                    onClick={() => setDossierCategory('elderly')}
                    className={`p-2 rounded cursor-pointer ${dossierCategory === 'elderly' ? 'bg-[#f59e0b] text-[#613b00] font-bold' : 'bg-[#262a35] text-[#dfe2f1]'}`}
                  >
                    Elderly / Disconnected
                  </button>
                </div>
              </div>

              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">FULL NAME</label>
                <input
                  type="text"
                  value={missingName}
                  onChange={(e) => setMissingName(e.target.value)}
                  placeholder="e.g. Ramesh Kulkarni"
                  className="w-full h-10 px-3 rounded bg-[#0a0e18] text-xs text-[#dfe2f1] border border-[#262a35] focus:outline-none focus:border-[#f59e0b]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">AGE</label>
                  <input
                    type="number"
                    value={missingAge}
                    onChange={(e) => setMissingAge(e.target.value)}
                    placeholder="e.g. 7"
                    className="w-full h-10 px-3 rounded bg-[#0a0e18] text-xs text-[#dfe2f1] border border-[#262a35] focus:outline-none focus:border-[#f59e0b]"
                  />
                </div>
                <div>
                  <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">WRISTBAND ID</label>
                  <input
                    type="text"
                    placeholder="Auto-Scan NFC"
                    className="w-full h-10 px-3 rounded bg-[#0a0e18] text-xs text-[#dfe2f1] border border-[#262a35] focus:outline-none focus:border-[#f59e0b]"
                  />
                </div>
              </div>

              <div>
                <label className="font-mono-code text-[10px] text-[#d8c3ad] block mb-1">PHYSICAL DESCRIPTORS</label>
                <textarea
                  rows={2}
                  value={missingDesc}
                  onChange={(e) => setMissingDesc(e.target.value)}
                  placeholder="Clothing color, height, spoken languages, landmark last seen..."
                  className="w-full p-2 rounded bg-[#0a0e18] text-xs text-[#dfe2f1] border border-[#262a35] focus:outline-none focus:border-[#f59e0b]"
                ></textarea>
              </div>
            </div>

            <button
              onClick={handleCreateDossier}
              className="w-full h-11 rounded-lg bg-[#f59e0b] text-[#613b00] font-chivo font-bold text-sm uppercase tracking-wide cursor-pointer active:scale-95 transition-transform"
            >
              Broadcast To All 18 Desks
            </button>
          </div>
        </div>
      )}

      {/* Sighting Dispatched Notification Toast */}
      {sightingReported && (
        <div className="fixed top-24 left-4 right-4 max-w-md mx-auto bg-emerald-950 text-emerald-200 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-50 border border-emerald-700/50">
          <span className="material-symbols-outlined text-2xl text-emerald-400">task_alt</span>
          <div className="flex flex-col min-w-0">
            <span className="font-chivo font-bold text-sm text-white">
              Sighting Dispatched to Desk #4
            </span>
            <span className="text-xs text-emerald-300">
              Field volunteers and nearby police patrol #14 alerted with GPS coordinates.
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
