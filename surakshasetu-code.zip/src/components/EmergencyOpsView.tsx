import React, { useState, useRef, useEffect } from 'react';

export const EmergencyOpsView: React.FC = () => {
  const [isAudible, setIsAudible] = useState<boolean>(true);
  const [sosDispatched, setSosDispatched] = useState<boolean>(false);
  const [holdProgress, setHoldProgress] = useState<number>(0);
  const [tripShieldActive, setTripShieldActive] = useState<boolean>(false);
  const [elderlyStatus, setElderlyStatus] = useState<string>('idle');
  const [tipSheetOpen, setTipSheetOpen] = useState<boolean>(false);
  const [tipCategory, setTipCategory] = useState<string>('Pickpocket / Theft');
  const [tipText, setTipText] = useState<string>('');
  const [tipSubmittedAlert, setTipSubmittedAlert] = useState<boolean>(false);

  const holdIntervalRef = useRef<any>(null);
  const maxHoldMs = 3000;
  const intervalStep = 50;
  const circumference = 2 * Math.PI * 46; // ~289

  const startHold = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (sosDispatched) return;
    setHoldProgress(0);
    clearInterval(holdIntervalRef.current);

    const startTime = Date.now();
    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / maxHoldMs, 1);
      setHoldProgress(progress);

      if (elapsed >= maxHoldMs) {
        clearInterval(holdIntervalRef.current);
        setSosDispatched(true);
        if (navigator.vibrate) {
          navigator.vibrate([300, 100, 300, 100, 500]);
        }
      }
    }, intervalStep);
  };

  const endHold = () => {
    clearInterval(holdIntervalRef.current);
    if (!sosDispatched) {
      setHoldProgress(0);
    }
  };

  useEffect(() => {
    const handleGlobalMouseUp = () => {
      if (!sosDispatched) {
        clearInterval(holdIntervalRef.current);
        setHoldProgress(0);
      }
    };
    window.addEventListener('mouseup', handleGlobalMouseUp);
    window.addEventListener('touchend', handleGlobalMouseUp);
    return () => {
      window.removeEventListener('mouseup', handleGlobalMouseUp);
      window.removeEventListener('touchend', handleGlobalMouseUp);
      clearInterval(holdIntervalRef.current);
    };
  }, [sosDispatched]);

  const cancelSOS = () => {
    setSosDispatched(false);
    setHoldProgress(0);
  };

  const triggerElderly = () => {
    setElderlyStatus('broadcasting');
    setTimeout(() => {
      setElderlyStatus('sent');
      setTimeout(() => setElderlyStatus('idle'), 3500);
    }, 1000);
  };

  const handleTipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTipSheetOpen(false);
    setTipSubmittedAlert(true);
    setTipText('');
    setTimeout(() => setTipSubmittedAlert(false), 4000);
  };

  const strokeDashoffset = circumference - holdProgress * circumference;
  const secondsLeft = Math.max(1, Math.ceil(3 - holdProgress * 3));

  return (
    <div className="flex flex-col w-full px-4 space-y-4 max-w-md mx-auto sm:max-w-xl md:max-w-2xl pb-6">
      {/* Mass Event Tactical Ribbon */}
      <section className="bg-[#171b26] rounded-xl p-3 shadow-md border border-[#262a35]/60">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-lg bg-[#f59e0b] text-[#613b00] flex items-center justify-center flex-shrink-0">
            <span className="material-symbols-outlined text-2xl">festival</span>
          </div>
          <div className="flex flex-col min-w-0 flex-1">
            <div className="flex items-center justify-between gap-1">
              <span className="font-mono-code text-[10px] text-[#f59e0b] uppercase font-bold tracking-wider">
                Mass Event Active
              </span>
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#262a35] text-[#54ddfc] font-mono-code text-[10px]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#54ddfc] animate-pulse"></span>
                DEFCON 2
              </span>
            </div>
            <p className="font-chivo text-base text-[#dfe2f1] font-semibold truncate mt-0.5">
              Dhammachakra Pravartan Din
            </p>
            <div className="flex items-center gap-1.5 mt-1 text-[#d8c3ad] font-mono-code text-[11px]">
              <span className="material-symbols-outlined text-sm text-[#f59e0b]">location_pin</span>
              <span className="truncate">Deekshabhoomi Ground • Sector 4 Helpdesk</span>
              <span className="px-1.5 py-0.5 rounded bg-[#313540] text-[#ffc174] font-bold text-[10px]">
                320m
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Big Tactical SOS Area */}
      <section className="bg-[#1c1f2a] rounded-xl p-4 flex flex-col items-center justify-center text-center relative overflow-hidden shadow-xl border border-[#313540]/60">
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-[#a40217]/10 rounded-full blur-2xl pointer-events-none"></div>
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-[#f59e0b]/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="w-full flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#ffb4ab] animate-ping"></span>
            <span className="font-mono-code text-[11px] uppercase tracking-wider text-[#ffb4ab] font-bold">
              Priority Red channel
            </span>
          </div>
          {/* Silent / Audible Toggle */}
          <button
            onClick={() => setIsAudible(!isAudible)}
            className="px-2.5 py-1 rounded-full bg-[#262a35] text-[#dfe2f1] flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer border border-[#313540]"
          >
            <span className={`material-symbols-outlined text-sm ${isAudible ? 'text-[#f59e0b]' : 'text-[#d8c3ad]'}`}>
              {isAudible ? 'volume_up' : 'volume_off'}
            </span>
            <span className={`font-mono-code text-[10px] uppercase font-semibold ${isAudible ? 'text-[#ffc174]' : 'text-[#d8c3ad]'}`}>
              {isAudible ? 'Audible Siren' : 'Silent Distress'}
            </span>
          </button>
        </div>

        {/* Hold to Activate SOS Button */}
        <div className="relative my-2 flex items-center justify-center">
          {/* Pulsing Radial Indicator */}
          <div
            className={`absolute w-44 h-44 rounded-full bg-[#a40217]/30 transition-transform ${
              holdProgress > 0 ? 'scale-125 duration-150' : 'scale-100 duration-500'
            }`}
          ></div>

          {/* Circular Progress SVG for 3s Press */}
          <svg className="absolute w-44 h-44 -rotate-90 pointer-events-none" viewBox="0 0 100 100">
            <circle
              className="text-[#313540]"
              cx="50"
              cy="50"
              fill="transparent"
              r="46"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <circle
              className="text-[#f59e0b] transition-all duration-75"
              cx="50"
              cy="50"
              fill="transparent"
              r="46"
              stroke="currentColor"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              strokeWidth="5"
            ></circle>
          </svg>

          <button
            onMouseDown={startHold}
            onTouchStart={startHold}
            className={`relative z-10 w-36 h-36 rounded-full text-[#ffdad6] flex flex-col items-center justify-center select-none active:scale-95 transition-all cursor-pointer ${
              sosDispatched
                ? 'bg-emerald-700 shadow-[0_0_24px_rgba(16,185,129,0.8)]'
                : 'bg-[#a40217] shadow-[0_0_24px_rgba(164,2,23,0.6)]'
            }`}
          >
            <span
              className="material-symbols-outlined text-4xl mb-0.5 text-[#ffdad6]"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              {sosDispatched ? 'check_circle' : 'emergency_home'}
            </span>
            <span className="font-chivo text-lg uppercase tracking-wider font-extrabold leading-none">
              {sosDispatched ? 'ACTIVE' : 'SOS'}
            </span>
            <span className="font-mono-code text-[10px] mt-1 text-[#ffdad6]/90 uppercase tracking-widest font-bold">
              {sosDispatched ? 'DISPATCHED' : holdProgress > 0 ? `${secondsLeft}s HOLD` : 'HOLD 3S'}
            </span>
          </button>
        </div>

        <div className="mt-2 flex flex-col items-center">
          <span className="font-mono-code text-[11px] text-[#dfe2f1] font-semibold">
            Immediate Field Responder Dispatch
          </span>
          <span className="text-xs text-[#d8c3ad] max-w-[280px] mt-0.5">
            Triangulates with Nagpur PCR Van 14 &amp; volunteers at Sector 4 Gate
          </span>
        </div>

        {/* SOS Confirmation Bar */}
        {sosDispatched && (
          <div className="mt-3 w-full p-2.5 rounded-lg bg-[#93000a] text-[#ffdad6] flex items-center justify-between animate-bounce">
            <div className="flex items-center gap-2 text-left">
              <span className="material-symbols-outlined text-xl">notification_important</span>
              <div>
                <p className="font-mono-code text-[11px] font-bold uppercase tracking-wider">
                  Distress Beacon Broadcasted
                </p>
                <p className="text-xs">Dispatched nearest Quick Response Team (ETA: 90s)</p>
              </div>
            </div>
            <button
              onClick={cancelSOS}
              className="px-2.5 py-1 bg-[#0f131d] text-[#dfe2f1] font-mono-code text-[10px] rounded uppercase font-bold active:scale-90 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        )}
      </section>

      {/* Rapid Interventions */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="font-chivo font-bold text-base text-[#dfe2f1] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#f59e0b] text-xl">bolt</span>
            Rapid Interventions
          </h2>
          <span className="font-mono-code text-[10px] text-[#d8c3ad] uppercase font-bold tracking-wider">
            3 Triggers Active
          </span>
        </div>

        <div className="flex flex-col space-y-3">
          {/* 1. Route Deviation Card */}
          <div className="bg-[#171b26] rounded-xl p-3 shadow-sm transition-all hover:bg-[#1c1f2a] border border-[#262a35]">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-lg bg-[#262a35] flex items-center justify-center text-[#ffc174] flex-shrink-0">
                <span className="material-symbols-outlined text-2xl">wrong_location</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-mono-code text-[10px] text-[#f59e0b] font-bold tracking-wider uppercase">
                    Auto / Transit Escort
                  </span>
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#1c1f2a] text-[#acedff] font-mono-code text-[10px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#acedff] animate-ping"></span>
                    Armed GPS
                  </span>
                </div>
                <h3 className="text-sm text-[#dfe2f1] font-semibold mt-0.5">
                  Route Deviation Auto-Sentinel
                </h3>
                <p className="text-xs text-[#d8c3ad] mt-1 leading-relaxed">
                  Live ride tracking: Auto-alerts 3 trusted contacts &amp; nearest PCR Van if off-course &gt;300m.
                </p>
                <div className="mt-2.5 flex items-center gap-2 pt-1">
                  <button
                    onClick={() => setTripShieldActive(!tripShieldActive)}
                    className={`px-3 py-1.5 rounded font-mono-code text-[11px] font-bold uppercase active:scale-95 transition-transform flex items-center gap-1 cursor-pointer ${
                      tripShieldActive
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#f59e0b] text-[#613b00]'
                    }`}
                  >
                    <span className="material-symbols-outlined text-sm">
                      {tripShieldActive ? 'shield' : 'navigation'}
                    </span>
                    <span>{tripShieldActive ? 'SHIELD ACTIVE' : 'ACTIVATE TRIP SHIELD'}</span>
                  </button>
                  <span className="text-[#d8c3ad] font-mono-code text-[10px]">
                    PCR #12 patrolling
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 2. Anonymous Tip Card */}
          <div className="bg-[#171b26] rounded-xl p-3 shadow-sm transition-all hover:bg-[#1c1f2a] border border-[#262a35]">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-lg bg-[#262a35] flex items-center justify-center text-[#54ddfc] flex-shrink-0">
                <span className="material-symbols-outlined text-2xl">visibility_off</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-mono-code text-[10px] text-[#54ddfc] font-bold tracking-wider uppercase">
                    Encrypted Field Lead
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-[#313540] text-[#d8c3ad] font-mono-code text-[10px]">
                    Witness Shield
                  </span>
                </div>
                <h3 className="text-sm text-[#dfe2f1] font-semibold mt-0.5">
                  Anonymous Crime / Tip Report
                </h3>
                <p className="text-xs text-[#d8c3ad] mt-1 leading-relaxed">
                  Photo upload with metadata scrubbing. Ex: "Suspicious activity / pickpocket near South Arch".
                </p>
                <div className="mt-2.5 flex items-center gap-2 pt-1">
                  <button
                    onClick={() => setTipSheetOpen(true)}
                    className="px-3 py-1.5 rounded bg-[#262a35] text-[#dfe2f1] font-mono-code text-[11px] font-bold uppercase active:scale-95 transition-transform flex items-center gap-1.5 cursor-pointer hover:bg-[#313540]"
                  >
                    <span className="material-symbols-outlined text-sm">add_a_photo</span>
                    <span>File Tip Fast</span>
                  </button>
                  <span className="text-[#d8c3ad] font-mono-code text-[10px] text-emerald-400 flex items-center gap-1">
                    <span className="material-symbols-outlined text-xs">lock</span> E2EE
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 3. Child / Elderly Beacon Card */}
          <div className="bg-[#171b26] rounded-xl p-3 shadow-sm transition-all hover:bg-[#1c1f2a] border border-[#262a35]">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-lg bg-[#262a35] flex items-center justify-center text-[#ffb3ad] flex-shrink-0">
                <span className="material-symbols-outlined text-2xl">accessibility_new</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-mono-code text-[10px] text-[#ffb3ad] font-bold tracking-wider uppercase">
                    Vulnerable Escort
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-[#a40217]/40 text-[#ffb3ad] font-mono-code text-[10px]">
                    500m Mesh Grid
                  </span>
                </div>
                <h3 className="text-sm text-[#dfe2f1] font-semibold mt-0.5">
                  Wandering Child / Elderly Ping
                </h3>
                <p className="text-xs text-[#d8c3ad] mt-1 leading-relaxed">
                  Broadcasts immediate physical descriptors to 42 stationed volunteers &amp; gate staff instantly.
                </p>
                <div className="mt-2.5 flex items-center gap-2 pt-1">
                  <button
                    onClick={triggerElderly}
                    className="px-3 py-1.5 rounded bg-[#262a35] text-[#ffb3ad] font-mono-code text-[11px] font-bold uppercase active:scale-95 transition-transform flex items-center gap-1.5 cursor-pointer hover:bg-[#313540]"
                  >
                    <span className={`material-symbols-outlined text-sm ${elderlyStatus === 'broadcasting' ? 'animate-spin' : ''}`}>
                      {elderlyStatus === 'sent' ? 'check_circle' : 'sensors'}
                    </span>
                    <span>
                      {elderlyStatus === 'broadcasting'
                        ? 'Broadcasting...'
                        : elderlyStatus === 'sent'
                        ? '42 Sentinels Alerted'
                        : 'Send Perimeter Alert'}
                    </span>
                  </button>
                  <span className="text-[#d8c3ad] font-mono-code text-[10px]">
                    48 Desk monitors
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Speed Dial Tactical Nodes */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="font-chivo font-bold text-base text-[#dfe2f1] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#54ddfc] text-xl">phone_in_talk</span>
            Emergency Direct Dials
          </h2>
          <span className="font-mono-code text-[10px] text-[#f59e0b]">0-LATENCY LINE</span>
        </div>

        <div className="grid grid-cols-1 gap-2">
          {/* Line 1: Police 112 */}
          <a
            className="p-3 rounded-xl bg-[#171b26] flex items-center justify-between active:scale-[0.98] transition-transform shadow-sm border border-[#262a35]"
            href="tel:112"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full bg-[#a40217] flex items-center justify-center text-[#ffdad6] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">local_police</span>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm text-[#dfe2f1] font-bold truncate">
                    Nagpur City Police Control
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-[#313540] text-[#ffb3ad] font-mono-code text-[10px]">
                    Priority
                  </span>
                </div>
                <p className="text-xs text-[#d8c3ad] font-mono-code mt-0.5">
                  Dial 112 • 4 PCR Vans in 1km
                </p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[#262a35] flex items-center justify-center text-[#f59e0b] flex-shrink-0">
              <span className="material-symbols-outlined">call</span>
            </div>
          </a>

          {/* Line 2: Ground Central Desk */}
          <a
            className="p-3 rounded-xl bg-[#171b26] flex items-center justify-between active:scale-[0.98] transition-transform shadow-sm border border-[#262a35]"
            href="tel:0712250000"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full bg-[#f59e0b] flex items-center justify-center text-[#472a00] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">shield_person</span>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm text-[#dfe2f1] font-bold truncate">
                    Deekshabhoomi Central Desk
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-[#313540] text-[#ffc174] font-mono-code text-[10px]">
                    On-Site
                  </span>
                </div>
                <p className="text-xs text-[#d8c3ad] font-mono-code mt-0.5">
                  Command Control Room • Gate 1
                </p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[#262a35] flex items-center justify-center text-[#f59e0b] flex-shrink-0">
              <span className="material-symbols-outlined">call</span>
            </div>
          </a>

          {/* Line 3: Medical Post */}
          <a
            className="p-3 rounded-xl bg-[#171b26] flex items-center justify-between active:scale-[0.98] transition-transform shadow-sm border border-[#262a35]"
            href="tel:108"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full bg-[#313540] flex items-center justify-center text-[#54ddfc] flex-shrink-0">
                <span className="material-symbols-outlined text-xl">medical_services</span>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm text-[#dfe2f1] font-bold truncate">
                    First Aid Post &amp; Ambulance
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-[#313540] text-[#54ddfc] font-mono-code text-[10px]">
                    Gate 3
                  </span>
                </div>
                <p className="text-xs text-[#d8c3ad] font-mono-code mt-0.5">
                  Dial 108 • 2 Critical Care Ambulances
                </p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[#262a35] flex items-center justify-center text-[#f59e0b] flex-shrink-0">
              <span className="material-symbols-outlined">call</span>
            </div>
          </a>
        </div>
      </section>

      {/* Live Verified Alert Bulletin Feed */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <h2 className="font-chivo font-bold text-base text-[#dfe2f1]">
              Field Operations Bulletins
            </h2>
          </div>
          <span className="font-mono-code text-[10px] text-[#d8c3ad]">Synced 42s ago</span>
        </div>

        <div className="space-y-2">
          {/* Alert 1 */}
          <div className="p-3 rounded-xl bg-[#171b26] shadow-sm border border-[#262a35]">
            <div className="flex items-center justify-between mb-1">
              <span className="inline-flex items-center gap-1 font-mono-code text-[10px] font-bold uppercase text-[#f59e0b]">
                <span className="material-symbols-outlined text-sm">traffic</span>
                Crowd Advisory
              </span>
              <span className="font-mono-code text-[10px] text-[#d8c3ad]">14:28 PM</span>
            </div>
            <p className="text-xs text-[#dfe2f1] font-medium leading-relaxed">
              Gate 2 Entry throttled for queue equalization. Directing incoming pedestrian stream to Sector 5 Outer Circle.
            </p>
            <div className="mt-2 flex items-center gap-2 text-[#d8c3ad] font-mono-code text-[10px]">
              <span>Auth: SP Traffic Nagpur</span>
              <span>•</span>
              <span className="text-[#54ddfc] font-medium">Clear Route: South Gate Ring</span>
            </div>
          </div>

          {/* Alert 2 */}
          <div className="p-3 rounded-xl bg-[#171b26] shadow-sm border border-[#262a35]">
            <div className="flex items-center justify-between mb-1">
              <span className="inline-flex items-center gap-1 font-mono-code text-[10px] font-bold uppercase text-[#54ddfc]">
                <span className="material-symbols-outlined text-sm">water_drop</span>
                Facility Update
              </span>
              <span className="font-mono-code text-[10px] text-[#d8c3ad]">14:10 PM</span>
            </div>
            <p className="text-xs text-[#dfe2f1] font-medium leading-relaxed">
              RO Drinking Water Tanker deployed between Pandal B &amp; Sector 3. ORS sachets available at First Aid Post 2.
            </p>
            <div className="mt-2 flex items-center gap-2 text-[#d8c3ad] font-mono-code text-[10px]">
              <span>Auth: Municipal Corporation Volunteer Wing</span>
            </div>
          </div>

          {/* Alert 3 - Resolved */}
          <div className="p-3 rounded-xl bg-[#171b26] shadow-sm opacity-80 border border-[#262a35]">
            <div className="flex items-center justify-between mb-1">
              <span className="inline-flex items-center gap-1 font-mono-code text-[10px] font-bold uppercase text-emerald-400">
                <span className="material-symbols-outlined text-sm">verified</span>
                Resolved Incident
              </span>
              <span className="font-mono-code text-[10px] text-[#d8c3ad]">13:45 PM</span>
            </div>
            <p className="text-xs text-[#dfe2f1]">
              Minor congestion cleared at Stupa East Staircase. Flow is stable.
            </p>
          </div>
        </div>
      </section>

      {/* Anonymous Tip Quick Bottom Sheet Modal */}
      {tipSheetOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full max-w-lg bg-[#1c1f2a] rounded-t-2xl sm:rounded-2xl p-4 space-y-3 shadow-2xl border border-[#313540]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-[#f59e0b] text-[#613b00] flex items-center justify-center">
                  <span className="material-symbols-outlined text-lg">security</span>
                </div>
                <h3 className="font-chivo font-bold text-base text-[#dfe2f1]">
                  Encrypted Incident Tip
                </h3>
              </div>
              <button
                onClick={() => setTipSheetOpen(false)}
                className="w-8 h-8 rounded-full bg-[#262a35] text-[#d8c3ad] flex items-center justify-center active:scale-95 cursor-pointer"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>

            <p className="text-xs text-[#d8c3ad]">
              Your identity and IP address are stripped before transmission to the Crime Branch Field Command.
            </p>

            <div className="space-y-1.5">
              <label className="block font-mono-code text-[10px] text-[#f59e0b] uppercase font-bold">
                Category
              </label>
              <div className="grid grid-cols-2 gap-2 font-mono-code text-[11px]">
                {['Pickpocket / Theft', 'Harassment', 'Barricade Stampede Risk', 'Medical Distress'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setTipCategory(cat)}
                    className={`p-2 rounded text-left transition-colors cursor-pointer ${
                      tipCategory === cat
                        ? 'bg-[#f59e0b] text-[#613b00] font-bold'
                        : 'bg-[#262a35] text-[#dfe2f1] hover:bg-[#313540]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="block font-mono-code text-[10px] text-[#d8c3ad] uppercase">
                Incident Details &amp; Landmark
              </label>
              <textarea
                value={tipText}
                onChange={(e) => setTipText(e.target.value)}
                className="w-full bg-[#0a0e18] text-[#dfe2f1] rounded p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#f59e0b] border border-[#262a35]"
                placeholder="e.g. Red cap individual near South Stupa stairs attempting wallet snatching..."
                rows={3}
              ></textarea>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                className="flex-1 py-2.5 rounded bg-[#262a35] text-[#dfe2f1] flex items-center justify-center gap-1.5 font-mono-code text-[11px] cursor-pointer hover:bg-[#313540]"
              >
                <span className="material-symbols-outlined text-base">photo_camera</span>
                <span>Attach Photo</span>
              </button>
              <button
                type="button"
                onClick={handleTipSubmit}
                className="flex-1 py-2.5 rounded bg-[#f59e0b] text-[#613b00] font-chivo text-sm uppercase font-bold active:scale-95 transition-transform cursor-pointer"
              >
                Dispatch Tip
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tip Submission Alert Toast */}
      {tipSubmittedAlert && (
        <div className="fixed top-24 left-4 right-4 max-w-md mx-auto bg-emerald-950 text-emerald-200 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-50 border border-emerald-700/50">
          <span className="material-symbols-outlined text-2xl text-emerald-400">lock</span>
          <div className="flex flex-col min-w-0">
            <span className="font-chivo font-bold text-sm text-white">
              Tip Securely Transmitted
            </span>
            <span className="text-xs text-emerald-300">
              Encrypted timestamp dispatched to Nagpur Crime Branch Field Unit.
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
